-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2025 at 03:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `levandapos`
--

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `post_code` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `country_id`, `post_code`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 213, 10, 'dar es salaam', '2025-05-24 09:24:13', '2025-05-24 09:24:13', NULL),
(2, 213, 41, 'DODOMA', '2025-05-25 02:24:45', '2025-05-25 02:24:45', NULL),
(3, 213, 30, 'GEITA', '2025-05-25 02:26:04', '2025-05-25 02:26:04', NULL),
(4, 213, 51, 'IRINGA', '2025-05-25 02:26:37', '2025-05-25 02:26:37', NULL),
(5, 213, 35, 'KAGERA', '2025-05-25 02:27:06', '2025-05-25 02:27:06', NULL),
(6, 213, 50, 'KATAVI', '2025-05-25 02:27:55', '2025-05-25 02:27:55', NULL),
(7, 213, 47, 'KIGOMA', '2025-05-25 02:28:28', '2025-05-25 02:28:28', NULL),
(8, 213, 25, 'KILIMANJARO', '2025-05-25 02:29:13', '2025-05-25 02:29:13', NULL),
(9, 213, 65, 'LINDI', '2025-05-25 02:29:50', '2025-05-25 02:29:50', NULL),
(10, 213, 27, 'MANYARA', '2025-05-25 02:30:23', '2025-05-25 02:30:23', NULL),
(11, 213, 31, 'MARA', '2025-05-25 02:31:01', '2025-05-25 02:31:01', NULL),
(12, 213, 53, 'MBEYA', '2025-05-25 02:31:51', '2025-05-25 02:31:51', NULL),
(13, 213, 67, 'MOROGORO', '2025-05-25 02:32:41', '2025-05-25 02:32:41', NULL),
(14, 213, 63, 'MTWARA', '2025-05-25 02:33:47', '2025-05-25 02:33:47', NULL),
(22, 213, 33, 'MWANZA', '2025-05-25 04:01:49', '2025-05-25 04:01:49', NULL),
(25, 213, 59, 'NJOMBE', '2025-05-25 04:08:29', '2025-05-25 04:08:29', NULL),
(26, 213, 61, 'PWANI', '2025-05-25 04:42:07', '2025-05-25 04:42:07', NULL),
(27, 213, 55, 'RUKWA', '2025-05-25 04:43:36', '2025-05-25 04:43:36', NULL),
(28, 213, 57, 'RUVUMA', '2025-05-25 04:59:14', '2025-05-25 04:59:14', NULL),
(29, 213, 37, 'SHINYANGA', '2025-05-25 05:00:26', '2025-05-25 05:00:26', NULL),
(30, 213, 39, 'SIMIYU', '2025-05-25 05:00:58', '2025-05-25 05:00:58', NULL),
(31, 213, 43, 'SINGIDA', '2025-05-25 05:01:43', '2025-05-25 05:01:43', NULL),
(32, 213, 45, 'TABORA', '2025-05-25 05:04:35', '2025-05-25 05:04:35', NULL),
(33, 213, 21, 'TANGA', '2025-05-25 05:05:16', '2025-05-25 05:05:16', NULL),
(34, 213, 54, 'SONGWE', '2025-05-25 05:08:27', '2025-05-25 05:08:27', NULL),
(35, 213, 23, 'ARUSHA', '2025-05-25 05:12:07', '2025-05-25 05:12:07', NULL),
(36, 213, 0, 'Unguja Kaskazini', '2025-07-30 15:27:44', '2025-07-30 15:27:44', NULL),
(37, 213, 0, 'Unguja Kusini', '2025-07-30 15:39:25', '2025-07-30 15:39:25', NULL),
(38, 213, 0, 'Unguja Mjini Magharibi', '2025-07-30 15:39:25', '2025-07-30 15:39:25', NULL),
(39, 213, 0, 'Pemba Kaskazini', '2025-07-30 15:39:25', '2025-07-30 15:39:25', NULL),
(40, 213, 0, 'Pemba Kusini', '2025-07-30 15:39:26', '2025-07-30 15:39:26', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `regions_country_id_foreign` (`country_id`),
  ADD KEY `regions_post_code_unique` (`post_code`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `regions`
--
ALTER TABLE `regions`
  ADD CONSTRAINT `regions_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
